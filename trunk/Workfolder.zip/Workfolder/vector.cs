using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

class CVector3
{
    public int x, y, z;
    public CVector3(int x = 0, int y = 0, int z = 0)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
}
